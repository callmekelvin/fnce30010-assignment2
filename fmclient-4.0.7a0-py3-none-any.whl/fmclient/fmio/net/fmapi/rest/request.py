"""
This module contains class which is responsible for all requests made to the API server
"""

import asyncio
import functools
import io
import json
import logging
import traceback
from enum import Enum
from json import JSONDecodeError
from typing import Callable, Union
from urllib import parse as urlparse

from aiohttp import ServerTimeoutError, ServerDisconnectedError, ClientResponse

from .fmsession import FMSession
from .....utils.constants import API_ROOT
from .....utils.logging import FMLogger

# """How many requests can be performed concurrently"""
concurrency = 10


class RequestMethod(Enum):
    """HTTP Verbs"""
    GET = "GET"
    POST = "POST"
    PATCH = "PATCH"
    PUT = "PUT"
    DELETE = "DELETE"


class Request:
    """
    Request class encapsulates all HTTP requests made to API server.

    Requests are performed based on HTTP verb selected during instantiation

    Requests cannot be performed simultaneously; only one at a time.

    For instance, if any of the method has been called on this Request, none of the other methods can be called until
    the current request has finished.
    """

    BASE_URL = API_ROOT.strip('/') + '/'  # Make sure it always ends with a '/' otherwise urljoin goes awry
    CONN_READ_TIMEOUT = 5 * 60  # Disable: 0, aiohttp default: 5 * 60

    def __init__(self, path: str,
                 callback_func: Union[Callable, callable, functools.partial],
                 error_callback_func: Union[Callable, callable, functools.partial] = None,
                 request_method: RequestMethod = RequestMethod.GET, params: dict = None,
                 data: str = None, data_as_file: bool = False,
                 response_parser: Union[Callable, callable, functools.partial] = None,
                 headers: dict = None, loop: asyncio.base_events.BaseEventLoop = None):
        """
        Create a Request to be performed using application-wide session

        :param path: Relative URL to request
        :param callback_func: Function to be called when request is successful
        :param error_callback_func: Function to be called when the request fails
        :param request_method: HTTP verb for this request
        :param params: Additional parameters to be passed with this request
        :param data: Data(str) payload to be sent
        :param data_as_file: Does the data need to be treated as file? If True, headers must be None. False by default
        :param response_parser: Custom parser for response data. Must be a callable. Default is JSON
        :param headers: Custom headers to be passed. This will replace default headers
        :param loop: Event loop to be used. If None, default event loop will be used
        """

        self._logger = FMLogger().get_logger(self.__class__.__name__, "comms")
        self._loop = loop
        self._verb = request_method.name
        self._callback = callback_func
        self._error_callback = error_callback_func
        self._params = params
        self._data_parser = response_parser
        self._semaphore = asyncio.Semaphore(concurrency)

        # Setup request
        if headers is None:
            headers = {'Content-Type': 'application/json'}
        self._headers = headers

        path = path.strip('/')  # Remove any redundant '/'. Urljoin will take care of this
        self._uri = urlparse.urljoin(self.BASE_URL, path)

        # Setup payload (if any)
        try:
            if data_as_file:
                self._data = {'file': io.BytesIO(bytearray(str(data), encoding='utf-8'))}
                self._headers = None
            else:
                self._data = json.dumps(data)
        except(TypeError, ValueError, OverflowError) as e:
            self._data = None
            self._logger.error(f"Couldn't serialise data to JSON. Data not sent to server.\n"
                               f"Underlying Exception: {e}")
        except Exception as e:
            self._logger.error(f"An unknown exception occurred during initialisation."
                               f"Underlying Exception: {e}")
            raise

    async def perform_forever(self, delay: int = 1):
        """
        Perform this request indefinitely, after a specified delay (in second)

        :param delay: how long (in seconds) to wait before performing this request again. Default is 1 second

        :return:
        """
        await self.perform_forever_conditionally(delay=delay)

    async def perform_forever_conditionally(
            self, delay: int = 1,
            condition: Union[Callable, callable, functools.partial] = lambda: True,
            should_continue: Union[Callable, callable, functools.partial] = lambda: True
    ):
        """
        Perform this request indefinitely, after a specified delay (in second), only if the condition resolves to True

        :param delay: how long (in seconds) to wait before performing this request again. Default is 1 second
        :param condition: a function or lambda that resolves to True
        :param should_continue: a function to indicate if the loop should continue
        :return:
        """
        while should_continue():
            if condition():
                await self.perform()
            else:
                self._logger.debug(f"Request Not Performed: {self} Reason: Condition Unsatisfied")

            # Now wait before trying again
            await asyncio.sleep(delay=delay)

        self._logger.debug(f"Request loop terminated: {self}. Reason: Loop continuation condition unsatisfied")

    async def perform(self):
        """
        Perform this request and returns parsed response via callbacks

        :return:
        """

        async def _load_response(response):
            if response.status == 200:
                # All went OK and now simply return data using the callback
                self._logger.debug("Started reading response text.")
                response_text = await response.text()
                self._logger.debug(f"Finished reading response text[{len(response_text)}].")
                try:
                    response_json = _parse_response(response_text)
                    callback_func = self._callback
                except Exception as ex:
                    self._logger.error(f"{type(ex).__name__}: {ex}")
                    self._logger.debug(traceback.format_exc())
                    self._logger.error(f"Error parsing server response. {response_text}")
                    response_json = _create_error_message(response, response_text)
                    callback_func = self._error_callback
            else:
                # It did not go OK, so now we return error message using error_callback
                callback_func = self._error_callback
                response_text = response.content.read_nowait().decode("utf-8")
                try:
                    error_response = _load_json(response_text)
                except Exception as ex:
                    self._logger.error(ex)
                    error_response = response_text

                response_json = _create_error_message(response, error_response)
                self._logger.debug(response_json)

            # Finally, do the callback
            return _do_callback(callback_func, response_json)

        def _parse_response(response_string):
            if self._data_parser and callable(self._data_parser):
                return self._data_parser(response_string)
            else:
                return _load_json(response_string)

        def _load_json(json_string):
            json_data = json.loads("{}")
            try:
                json_data = json.loads(json_string)
            except JSONDecodeError:
                self._logger.error(' '.join(
                    ["Couldn't parse response from server as JSON.",
                     "Perhaps use a custom data parser if expecting response in different format.",
                     f"Returning empty data {json_data}."]
                ))
                raise
            finally:
                return json_data

        def _create_error_message(server_response, message):
            err_msg = {
                'response': message
            }
            dbg_msg = {}

            if server_response and isinstance(server_response, ClientResponse):
                err_msg['code'] = server_response.status

                if self._logger.getEffectiveLevel() == logging.DEBUG:
                    dbg_msg = {
                        'content_type': server_response.content_type,
                        'charset': server_response.charset,
                        'request_type': server_response.method,
                        'request': server_response.url,
                        'response_headers': server_response.headers,
                        'request_headers': server_response.request_info.headers
                    }

            return {**err_msg, **dbg_msg}

        def _do_callback(callback_func, response_json):
            if callback_func and callable(callback_func):
                self._logger.debug(f" DO Callback {callback_func}")
                return callback_func(response_json)

        # Perform this request
        async with self._semaphore:
            try:
                self._logger.debug(f" DO {self} with Sem:{self._semaphore}")
                async with FMSession(loop=self._loop).request(self._verb, self._uri, self._params, self._data,
                                                              self._headers) as resp:
                    load_return = await _load_response(resp)
                self._logger.debug(f"DID {self}")
            except (ServerTimeoutError, asyncio.TimeoutError) as ste:
                self._logger.error(f"Server Timeout: {ste}; {self}")
                load_return = _do_callback(self._error_callback, _create_error_message(None, ste))
            except ServerDisconnectedError as sde:
                self._logger.error(f"Server Disconnected Error: {sde}; {self}")
                load_return = _do_callback(self._error_callback, _create_error_message(None, sde))
            except ValueError as ve:
                raise ConnectionError(ve)  # When FMAuth isn't yet present

        return load_return

    def __str__(self):
        return " ".join([self._verb, self._uri, ])
