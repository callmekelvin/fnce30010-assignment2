import asyncio
import functools
import logging
import traceback
from collections import defaultdict
from enum import Enum
from typing import Union, Callable

from autobahn.asyncio.websocket import WebSocketClientProtocol
from autobahn.websocket.types import ConnectionResponse

from .....utils.helper import run_or_schedule_coroutine


# Set of callbacks to be performed based on callback type. Default action is to do nothing
_callbacks = defaultdict(lambda: defaultdict(list))


def register_ws_callback(cb_type, instance):
    """Decorator to register a callable for given callback type"""
    def decorator_register_callback(func):
        """Register func as one of the callbacks for supplied callback type"""
        if callable(func):
            global _callbacks
            _callbacks[instance][cb_type].append([func, instance])
        return func
    return decorator_register_callback


class AgentWebSocketCallbackType(Enum):
    CONNECT = 1
    OPEN = 2
    CLOSE = 3
    MESSAGE = 4


class AgentWebSocketClientProtocol(WebSocketClientProtocol):
    """
    Class to implement the websocket protocol for all types of WS connections, irrespective of provider.
    This class defines the event handlers for incoming and methods for outgoing messages.
    """

    def __init__(self):
        super().__init__()
        self._is_connected = False
        self._client = None
        self._logger = logging.getLogger("ws.protocol")
        # self._logger.setLevel(logging.DEBUG)  # Dev Only

    @property
    def is_connected(self) -> bool:
        return self._is_connected

    def client(self, ws_client):
        self._client = ws_client
    client = property(None, client)  # Setter only

    def __perform_callbacks(self, cb_type: AgentWebSocketCallbackType, *args, **kwargs):
        global _callbacks
        _todo = _callbacks[self._client][cb_type]
        self._logger.debug(self._create_msg(f"Callbacks: {_todo}"))

        async def _act(cb, them):
            try:
                self._logger.debug(self._create_msg(f"Performing Callback: {cb}"))
                cb(them, *args, **kwargs)
            except Exception as e:
                self._logger.error(self._create_msg(f"Error '{e}' while performing callback: '{cb}'"))
                self._logger.error(traceback.format_exc())

        for _cb in _todo:
            run_or_schedule_coroutine(_act(_cb[0], _cb[1]))

    def onConnect(self, response: ConnectionResponse) -> None:
        self._logger.debug(self._create_msg(f"Server connected"))
        self.__perform_callbacks(AgentWebSocketCallbackType.CONNECT, response)

    async def onOpen(self):
        self._logger.debug(self._create_msg(f"Connection open"))
        self._is_connected = True
        self.__perform_callbacks(AgentWebSocketCallbackType.OPEN)

    def onMessage(self, payload, is_binary):
        if is_binary:
            self._logger.debug(self._create_msg(f"Binary message received: {len(payload)} bytes"))
        else:
            message = payload.decode('utf-8')
            self._logger.debug(self._create_msg(f"Received Message: {message}"))
            self.__perform_callbacks(AgentWebSocketCallbackType.MESSAGE, message)

    def onClose(self, was_clean, code, reason):
        self._logger.debug(self._create_msg(f"Connection closed: {reason}"))
        self._is_connected = False
        self.__perform_callbacks(AgentWebSocketCallbackType.CLOSE, code, reason)

    def send_message(self, message: str, encoder: Union[Callable, functools.partial] = lambda x: str(x)):
        """
        Send messages over websocket protocol

        :param message: Message to be sent
        :type message: str-like objects
        :param encoder: a callable that converts message to string and appropriate encoding
        :type encoder: a callable, partial from functool or lambda, which takes a single argument
        :return:
        :rtype:
        """
        self._logger.debug(self._create_msg(f"Sending message"))
        try:
            self._logger.debug(encoder(message).encode('utf-8'))
            super().sendMessage(encoder(message).encode('utf-8'))
            # super().sendMessage(json.dumps(message, default=lambda o: str(o)).encode("utf-8"))
        except Exception as e:
            self._logger.error(self._create_msg(f"Error '{e}' while sending message '{message}'"))
            self._logger.debug(traceback.format_exc())

    def _create_msg(self, message: str):
        return f"[{self.peer}]: {message}"
