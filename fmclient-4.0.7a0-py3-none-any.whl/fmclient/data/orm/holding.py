"""
Classes and methods to work with holdings
"""
from __future__ import annotations

from typing import Dict

from .market import Asset, Market
from .marketplace import Marketplace
from .session import Session
from .user import User


class Holding(object):
    """
    A Holding entity for marketplace that represents current holding for a user.

    Each holding has associated Asset objects that store current cash and units for this holding, associated with a
    market.

    In order to initialise this object, a dict with following keys need to be passed:
        ['assets', 'cash', 'availableCash', 'initialCash', 'name', 'marketplace', 'owner']
    'marketplace' and 'owner' must be a dict with at least an 'id' field.
    These are associated objects of `Marketplace` and `User`.

    .. Note:: This class does **not** support :py:func:`copy` and :method:`deepcopy`
        from Python's :py:module:`copy` module.
    """

    assets: Dict[Market, Asset]
    cash: int
    cash_available: int
    cash_initial: int
    name: str
    marketplace: Marketplace
    owner: User
    session: Session

    __fields = {
        'assets': ('assets', lambda x: {Asset(y).market: Asset(y) for y in x}),  # y-dict in x-list
        'cash': ('cash', int),
        'availableCash': ('cash_available', int),
        'initialCash': ('cash_initial', int),
        'name': ('name', str),
        'marketplaceId': ('marketplace', Marketplace),  # FM-3
        'ownerId': ('owner', User),  # FM-3
        'sessionId': ('session', Session),  # FM-3
    }
    __assoc_obj_lookup_fields = {
        'marketplace': ('marketplace', Marketplace),
        'owner': ('owner', User),
        'session': ('session', Session),
    }
    __field_validations = {
        'cash_initial': lambda x: x >= 0,
        'cash': lambda x: False,  # Prevents modification
        'cash_available': lambda x: False,  # Prevents modification
        'assets': lambda x: False,  # Prevents modification
    }

    __enabled_attrs = set([_[0] for _ in __fields.values()])
    __enabled_attrs.update(list(__assoc_obj_lookup_fields))
    _fields = tuple(__enabled_attrs)
    _field_defaults = {}

    # Add additional attributes
    __enabled_attrs.update('_new'.split())
    _new = True  # Relevant only for objects but not on class, however, it is required
    __print_fields = 'name owner cash cash_available cash_initial assets'.split()

    def __new__(cls, options: dict = None) -> Holding:
        obj = super().__new__(cls)
        obj._new = True

        if options:
            for option, value in options.items():
                if option in cls.__fields:
                    attr, type_ = cls.__fields[option]
                    obj.__setattr__(attr, type_(value))
                elif option in cls.__assoc_obj_lookup_fields:
                    attr, type_ = cls.__assoc_obj_lookup_fields[option]
                    try:
                        obj.__setattr__(attr, type_(value['id']))
                    except ValueError:
                        obj.__setattr__(attr, type_(value['id'], value))
        obj._new = False

        return obj

    def __str__(self) -> str:
        info = ','.join([str(getattr(self, f)) for f in self.__print_fields if hasattr(self, f)])
        return f"Holding({info if info else None})"

    def __repr__(self) -> str:
        return self.__str__()

    def __getattr__(self, attr):
        if attr not in self.__enabled_attrs:
            raise AttributeError(attr)

        # Fetch a remote value here and return it
        if attr not in self.__dict__:
            raise AttributeError(attr)
        return self.__dict__[attr]

    def __setattr__(self, attr, value):
        if attr not in self.__enabled_attrs:
            raise AttributeError(f"Holding object does not support attribute `{attr}`")

        # Perform any validations
        if not self._new and attr in self.__field_validations:
            validate = self.__field_validations[attr]
            if callable(validate) and not validate(value):
                raise ValueError(f"Cannot set {attr} to {value}")

        # Set a remote value here
        self.__dict__[attr] = value
