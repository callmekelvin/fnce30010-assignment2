"""
Module to encapsulate user information from Flex-e-markets
"""
from __future__ import annotations

import copy
from datetime import datetime
from enum import Enum
from typing import List, Dict

from ...utils.helper import string_to_local_date


class UserRole(Enum):
    USER = 0
    ROLE_USER = 0

    MANAGER = 1
    ROLE_MANAGER = 1

    def __str__(self):
        return f"{self.name}"

    def __repr__(self):
        return self.__str__()


class User(object):
    """
    A User is a trader that has been added to the current marketplace in FM

    This class only creates a User object if doesn't already exist. This ensures reuse and unified storage.

    In order to initialise this object, a dict with following keys need to be passed
        ['id', 'firstName', 'lastName', 'email', 'roles', 'createdDate', 'lastModifiedDate']

    .. Note:: This class does **not** support :py:func:`copy` and :method:`deepcopy`
        from Python's :py:module:`copy` module.
    """

    fm_id: int
    first_name: str
    last_name: str
    email: str
    roles: List[UserRole]
    date_created: datetime
    date_last_modified: datetime

    __instances_by_id = {}
    __instances_by_email = {}
    __fields = {
        'id': ('fm_id', int),
        'firstName': ('first_name', str),
        'lastName': ('last_name', str),
        'email': ('email', str),
        'roles': ('roles', list),
        'createdDate': ('date_created', string_to_local_date),
        'lastModifiedDate': ('date_last_modified', string_to_local_date),
    }
    __enabled_attrs = set([_[0] for _ in __fields.values()])
    _fields = tuple(__enabled_attrs)
    _field_defaults = {}

    __enabled_attrs.update('_id _locked'.split())
    _locked = False  # Relevant only for objects but not on class

    __print_fields = 'fm_id first_name last_name email roles'.split()

    def __new__(cls, id_, options: dict = None) -> User:
        id_ = int(id_)  # FM sometimes sends a string
        if id_ not in cls.__instances_by_id:
            obj = super().__new__(cls)
            obj._locked = False
            obj._id = id_

            if options:
                for option, value in options.items():
                    if option in cls.__fields:
                        attr, type_ = cls.__fields[option]
                        obj.__setattr__(attr, type_(value))

                if hasattr(obj, 'roles'):
                    _roles = obj.roles
                    obj.roles = [UserRole[str(r)] for r in _roles]

                if hasattr(obj, 'email'):
                    User.__instances_by_email[obj.email] = obj

                obj._locked = True
                cls.__instances_by_id[id_] = obj

        try:
            return cls.__instances_by_id[id_]
        except KeyError:
            raise ValueError(f"User({id_}) does not exist")

    def __eq__(self, other):
        return self._id == other._id if isinstance(other, User) else False

    def __hash__(self):
        return hash(self._id)

    def __str__(self):
        info = ','.join([str(getattr(self, f)) for f in self.__print_fields if hasattr(self, f)])
        return f"User({info if info else self._id})"

    def __repr__(self):
        rep = ','.join(
            [':'.join([repr(f), repr(getattr(self, v[0]))]) for f, v in self.__fields.items() if hasattr(self, v[0])]
        )
        return f"User({self._id}, {{{rep}}})"

    def __getattr__(self, attr):
        if attr not in self.__enabled_attrs:
            raise AttributeError(attr)

        # Fetch a remote value here and return it
        if attr not in self.__dict__:
            raise AttributeError(attr)
        return self.__dict__[attr]

    def __setattr__(self, attr, value):
        if attr not in self.__enabled_attrs:
            raise AttributeError(attr)
        if self._locked:
            raise TypeError("'User' object cannot be modified after creation")

        # Set a remote value here
        self.__dict__[attr] = value

    @classmethod
    def get_by_id(cls, id_) -> User:
        return cls.__instances_by_id.get(id_, None)

    @classmethod
    def get_by_email(cls, email) -> User:
        return cls.__instances_by_email.get(email, None)

    @classmethod
    def all(cls) -> Dict[int, User]:
        return copy.copy(cls.__instances_by_id)
