"""
The fmclient python package provides a library that eases the development of
automated trading algorithms that interact with Flex-e-markets servers.
It provides a high level functionality to interact with the platform as a trader
as well as a manager using Python programming language.

Following Environment Variables are in place to configure the library:

FM_HOST(str):
    -   Defines the FM host to use
    -   Values: FM | AHM
    -   Default: FM

FM_WS_SSL(bool):
    -   Whether to use SSL to connect to FM WebSockets
    -   Values: True | False
    -   Default: True

BOT_WS_DOMAIN(str):
    -   Defines the domain to use for WS messages, in case routing these messages to a separate host
    -   Default: algohost.bmmlab.org

BOT_WS_PORT(int):
    -   Port for the above WS domain
    -   Values: 80(http|ws) | 443(https|wss) | xxxx(non-standard)
    -   Default: 443(https|wss)

BOT_WS_SSL(bool):
    -   Whether to use SSL to connect to AlgoHost via WebSockets
    -   Values: True | False
    -   Default: True

WS_SIMULATE(bool):
    -   Whether to only simulate sending messages over WS
    -   Values: True | False
    -   Default: False
"""

# Version
__version__ = '4.0.7-alpha'

__name__ = 'fm-client'

from .data.message import MessageType
from .data.orm.holding import Holding
from .data.orm.market import Market, Asset
from .data.orm.marketplace import Marketplace, MarketplaceState
from .data.orm.order import Order, OrderSide, OrderType
from .data.orm.session import Session, SessionState
from .data.orm.user import User, UserRole
from .utils.logging import DynamicFileHandler
from .utils import helper as hlp
from .base.agent import Agent  # Must be imported last

__all__ = [
    Agent,
    Holding,
    Market,
    Asset,
    Marketplace,
    Order,
    OrderSide,
    OrderType,
    Session,
    SessionState,
    User,
    UserRole
]
