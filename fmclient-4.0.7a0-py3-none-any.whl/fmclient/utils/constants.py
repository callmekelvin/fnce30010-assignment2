import os

from . import helper as hlp
from .. import __version__ as lib_version

# Version
LIB_VERSION = lib_version
LIB_NAME = 'FM Client'

# Available FM Servers
FM_HOSTS = {'FM': (FM_HOST_FM := 'FM'), 'AHM': (FM_HOST_AHM := 'AHM')}
# Set default server
FM_HOST_DEFAULT = FM_HOST_AHM
"""
Default FM HOST to connect.

    ... versionchanged: 4.0.5
        Default is now to use AHM (FM-3). Previous versions used FM-2 as default.
"""
FM_HOST_SERVERS = {
    FM_HOST_FM: "https://guarded-ridge-89710.herokuapp.com",
    FM_HOST_AHM: "https://fm-data.herokuapp.com"
}

# Set host for application
FM_HOST = FM_HOSTS.get(os.environ.get('FM_HOST', FM_HOST_DEFAULT), FM_HOST_DEFAULT)

# Root URL
FM_ROOT = FM_HOST_SERVERS[FM_HOST]

API_PATH = "/api"
API_ROOT = f"{FM_ROOT}{API_PATH}"

# FM WS Endpoint
FM_WS_ROOT = FM_ROOT.replace('http', 'ws')
FM_WS_PATH = f"{API_PATH}/events"
FM_WS_SSL = hlp.str_to_bool(os.environ.get("FM_WS_SSL", "True"))

# Main API Endpoints
# FM-3 REST API endpoints are now rooted at following two prefixes only
#   1. API_ROOT/accounts/{id}
#   2. API_ROOT/marketplaces/{id}
# NOTE: This should be taken into account when cleaning up requests made.
ACCOUNT_URI = "/accounts/$id$"
ACCOUNT_URL = f"{API_ROOT}{ACCOUNT_URI}"
MARKETPLACE_URI = "/marketplaces/$id$"
MARKETPLACE_URL = f"{API_ROOT}{MARKETPLACE_URI}"

# Other API Endpoints
HOLDINGS_EXPORT_URI = f"{MARKETPLACE_URI}/holdings/downloads?sessions=last"
HOLDINGS_EXPORT_URL = f"{API_ROOT}{HOLDINGS_EXPORT_URI}"
SESSION_HOLDINGS_EXPORT_URI = f"{MARKETPLACE_URI}/holdings/downloads?sessions=$session_id$"
SESSION_HOLDINGS_EXPORT_URL = f"{API_ROOT}{HOLDINGS_EXPORT_URI}"
HOLDINGS_JSON_EXPORT_URI = f"{MARKETPLACE_URI}/holdings"
HOLDINGS_JSON_EXPORT_URL = f"{API_ROOT}{HOLDINGS_JSON_EXPORT_URI}"

# NOTE: Following endpoints are accessible by ROLE_MANAGER only
#  /api/users/{userId}
#  /api/users-json/{userId}
USERS_URI = "/users-json"
USERS_URL = f"{API_ROOT}{USERS_URI}"
# TODO: For normal users, use information in authentication token which contains the account and user information.
#  This is also the best option since it does not require a round-trip.
#  After REST API refactoring, following endpoint will be available for "self" in addition to managers:
#  /api/accounts/{accountId}/users/{userId}

HOLDINGS_IMPORT_URI = f"{MARKETPLACE_URI}/holdings/uploads"
HOLDINGS_IMPORT_URL = f"{API_ROOT}{HOLDINGS_IMPORT_URI}"

HOLDINGS_CSV_HEADER = "# holdings -- begin"
HOLDINGS_CSV_FOOTER = "# holdings -- end"

ORDERS_CSV_HEADER = "# orders -- begin"
ORDERS_CSV_FOOTER = "# orders -- end"

# Connection Configuration
ASYNCIO_MAX_THREADS = 2

# Agent Reporting and Monitoring Configuration
MONITOR_ORDER_BOOK_DELAY = 0.25

# WebSocket Communication Configuration
WS_MESSAGE_DELAY = 0.1
WS_ADDRESS = os.environ.get("BOT_WS_DOMAIN", "algohost.bmmlab.org")
WS_PORT = int(os.environ.get("BOT_WS_PORT", 443))
WS_SSL = hlp.str_to_bool(os.environ.get("BOT_WS_SSL", "True"))
WS_PATH = "/chat/stream/"
WS_SIMULATE = hlp.str_to_bool(os.environ.get("BOT_WS_SIMULATE", "False"))
