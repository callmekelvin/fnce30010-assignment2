# Print iterations progress
def progress_bar(iteration, total, prefix='', suffix='', decimals=1, length=100, fill='█', end="\r"):
    """
    Call in a loop to create terminal progress bar

    :param iteration: current iteration (Int) - Required
    :param total: total iterations (Int) - Required
    :param prefix: prefix string (Str) - Optional
    :param suffix: suffix string (Str) - Optional
    :param decimals: positive number of decimals in percent complete (Int) - Optional
    :param length: character length of bar (Int) - Optional
    :param fill: bar fill character (Str) - Optional
    :param end: end character (e.g. '\\r', '\\r\\n') (Str) - Optional
    """
    percent = f"{(100 * (iteration / float(total))):.{decimals}f}"
    filled_length = int(length * iteration // total)
    bar = f"{fill * filled_length}{'-' * (length - filled_length)}"
    print(f"\r{prefix} |{bar}| {percent}% {suffix}", end=end)
    # Print New Line on Complete
    if iteration == total:
        print()
