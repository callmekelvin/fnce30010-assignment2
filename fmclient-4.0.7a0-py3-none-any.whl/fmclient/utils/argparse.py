import argparse

parser = argparse.ArgumentParser(
    description="A margin robot based on FM Client for Induced Demand and Supply project",
    epilog="A marketplace must first be created with accounts added for robots on Flex-e-markets"
)

parser.add_argument("--account",
                    nargs='?', const="FM_ACCOUNT", default="FM_ACCOUNT",
                    help='account string from Flex-e-markets')
parser.add_argument("--email",
                    nargs='?', const="FM_EMAIL", default="FM_EMAIL",
                    help='email for this user')
parser.add_argument("--passwd",
                    nargs='?', const="FM_PASSWORD", default="FM_PASSWORD",
                    help='password for this user')
parser.add_argument("--mp-id",
                    nargs='?', const="MP_ID", default="MP_ID", type=int,
                    help='marketplace ID from Flex-e-markets')

args = parser.parse_args()
